#!/usr/bin/env python3
"""Verify every extracted source, original archive and generated bundle file."""
import hashlib
import json
from pathlib import Path, PurePosixPath

root = Path(__file__).resolve().parent
manifest = json.loads((root / "bundle-manifest.json").read_text())
expected = set()
for entry in manifest["files"]:
    name = PurePosixPath(entry["path"])
    if name.is_absolute() or ".." in name.parts or entry["path"] in expected:
        raise SystemExit("Unsafe or duplicate manifest path")
    expected.add(entry["path"])
    path = root.joinpath(*name.parts)
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
        raise SystemExit("Missing ordinary bundle file")
    data = path.read_bytes()
    if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
        raise SystemExit("Bundle content checksum differs")
    if oct(path.stat().st_mode & 0o777) != entry["mode"]:
        raise SystemExit("Bundle file permissions differ")
actual = set()
for path in root.rglob("*"):
    if path.is_symlink():
        raise SystemExit("Unexpected bundle symlink")
    if path.is_file() and path != root / "bundle-manifest.json":
        actual.add(str(path.relative_to(root)))
if actual != expected:
    raise SystemExit("Bundle file inventory differs")
for crate in manifest["registry_crates"]:
    directory = root / crate["vendor_directory"]
    checks = json.loads((directory / ".cargo-checksum.json").read_text())
    if checks["package"] != crate["sha256"]:
        raise SystemExit("Cargo package checksum differs")
    for name, digest in checks["files"].items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
            raise SystemExit("Cargo source file checksum differs")
print(json.dumps({"result": "passed_source_bundle_integrity", "registry_crates": len(manifest["registry_crates"]),
                  "files_verified": len(expected), "compiled_provenance_verified": False}))
