# Pydantic-core 2.46.4 offline source preparation

This bundle contains the original PyPI sdist, the 103 exact registry archives
selected by its Cargo.lock, complete extracted source, Cargo directory-source
checksums, original source/build metadata and retained publisher notices.
The crate set includes build/test/alternative-platform candidates. It is not
an assertion that all 103 crates occur in a particular compiled wheel.

Run `python3 verify-bundle.py` after transport. The bundle manifest is independently
SHA-bound by the repository's local L05 preparation report. The generated
`.cargo/config.toml` replaces crates.io with the local vendor directory and
disables network use. Original publisher source configuration is retained.

## Required builder (not supplied or demonstrated)

- Linux x86_64/AMD64, with a compatible C compiler/linker and system headers.
- CPython 3.13 development/interpreter files for the intended ABI.
- Rust >=1.88, Cargo, and the x86_64-unknown-linux-gnu standard-library target.
- Maturin >=1.10,<2, already installed; no package installation occurs here.

Set `PYO3_PYTHON` to that interpreter and `LOVELIES_PYDANTIC_BUILD_OUTPUT` to a
new absolute directory outside this bundle, then run `sh rebuild-linux-amd64.sh`.
The recipe captures actual compiler/ABI versions, Cargo metadata, target feature
tree, build log and candidate wheel hash. No compilation was performed during
source preparation; recipe compatibility with an actual builder remains untested.
Preserve the bundle plus those receipts. A replacement candidate still requires
the full runtime regressions and renewed image/native/source/licence/SBOM bindings.
This bundle does not authenticate the earlier publisher wheel's compiled features,
close the five Rust advisory candidates or approve a production release.
