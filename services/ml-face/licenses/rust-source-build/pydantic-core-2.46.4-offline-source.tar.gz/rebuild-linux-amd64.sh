#!/bin/sh
# Requires an already provisioned Linux AMD64 builder; never installs tools or downloads inputs.
set -eu
bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
python_bin=${PYO3_PYTHON:?Set PYO3_PYTHON to the Linux AMD64 CPython 3.13 interpreter}
build_output=${LOVELIES_PYDANTIC_BUILD_OUTPUT:?Set a new absolute output directory outside the source bundle}
test "$(uname -s)" = Linux && test "$(uname -m)" = x86_64
for tool in cargo rustc maturin cc; do command -v "$tool" >/dev/null; done
"$python_bin" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 13) else 1)'
"$python_bin" "$bundle_dir/verify-bundle.py"
"$python_bin" -c 'import re, subprocess; v=subprocess.check_output(["rustc","--version"],text=True); m=re.match(r"rustc (\d+)\.(\d+)",v); raise SystemExit(0 if m and tuple(map(int,m.groups())) >= (1,88) else 1)'
"$python_bin" -c 'import re, subprocess; v=subprocess.check_output(["maturin","--version"],text=True); m=re.search(r"(\d+)\.(\d+)",v); raise SystemExit(0 if m and (1,10) <= tuple(map(int,m.groups())) < (2,0) else 1)'
case "$build_output" in /*) ;; *) echo "Build output must be absolute" >&2; exit 2;; esac
case "$build_output/" in "$bundle_dir/"*) echo "Build output must be outside bundle" >&2; exit 2;; esac
test ! -e "$build_output"
mkdir -m 700 "$build_output"
export PYO3_PYTHON="$python_bin" CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$build_output/target"
source_dir="$bundle_dir/source/pydantic_core-2.46.4"
cd "$source_dir"
rustc --version --verbose > "$build_output/rustc.txt"
cargo --version > "$build_output/cargo.txt"
maturin --version > "$build_output/maturin.txt"
cc --version > "$build_output/cc.txt"
"$python_bin" -c 'import json,platform,sys,sysconfig; print(json.dumps({"version":sys.version,"platform":platform.platform(),"SOABI":sysconfig.get_config_var("SOABI")}))' > "$build_output/python.json"
cargo metadata --frozen --offline --format-version 1 --filter-platform x86_64-unknown-linux-gnu > "$build_output/cargo-metadata.json"
cargo tree --frozen --offline --target x86_64-unknown-linux-gnu --edges normal,build,features > "$build_output/cargo-feature-tree.txt"
maturin build --locked --offline --release --target x86_64-unknown-linux-gnu --interpreter "$python_bin" --out "$build_output/wheels" > "$build_output/build.log" 2>&1
sha256sum "$build_output"/wheels/*.whl > "$build_output/wheel-sha256.txt"
"$python_bin" "$bundle_dir/verify-bundle.py"
echo "Candidate wheel built. Test it and regenerate exact-image licensing/SBOM/artifact evidence before acceptance."
