# Account-free still package notices

This wheel contains selected first-party OpenFace Python primitives and the
account-free adapter. The first-party grant is preserved in
`LICENSE-FIRST-PARTY.md`. It contains no ONNX model files, native OpenCV binary,
PAD/video model or third-party source checkout.

The consuming runtime supplies OpenCV, NumPy and Pillow and must retain the
licenses/notices for its exact installed distributions and linked components.
Using an image-only OpenCV build does not waive its own component obligations.

The model contract identifies YuNet (MIT; copyright2020 Shiqi Yu) and SFace
(Apache-2.0) from OpenCV Zoo using the existing authorized Memories source
assets. The model distribution must accompany the actual files with
`licenses/YuNet-MIT.txt`, `licenses/Apache-2.0.txt` and its exact provenance.
Neither this notice nor the source package transfers training-data rights or
supplies intended-use approval. The source repository's full notices remain
applicable to any separately selected artifacts.
