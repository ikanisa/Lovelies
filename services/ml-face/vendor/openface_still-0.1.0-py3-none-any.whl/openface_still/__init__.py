"""Credential-free still inference; no account, broker, PAD or network service."""
from .artifact import ENGINE_ARTIFACT_SHA256, verify_artifact
from .engine import StillFace, StillImageEngine, StillImagePolicy, StillImageResult
from .runtime import StillImageRuntime
from ._core.errors import PlatformError

__version__ = "0.1.0"
__all__ = ["ENGINE_ARTIFACT_SHA256", "PlatformError", "StillFace", "StillImageEngine",
           "StillImagePolicy", "StillImageResult", "StillImageRuntime", "verify_artifact"]
