# First-party delivery
The newly authored platform code is supplied to IKANISA for its internal development,
modification and deployment. No public open-source licensing decision is imposed on
the user's proprietary platform. Third-party artifacts and derived source retain
their own license terms; see THIRD_PARTY_NOTICES.md.
