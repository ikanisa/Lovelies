"""Fail-closed identity of exact built source and versioned primitive contract."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent


def verify_artifact() -> str:
    manifest = json.loads((ROOT / "build-manifest.json").read_bytes())
    members = manifest["source_members"]
    if (manifest["contract_version"] != "openface-still-v1" or not isinstance(members, dict)
            or not 8 <= len(members) <= 32):
        raise RuntimeError("still_artifact_manifest_invalid")
    actual_members = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*")
                      if p.is_file() and (p.suffix == ".py" or p.name == "contract.json")}
    if set(members) != actual_members:
        raise RuntimeError("still_artifact_members_changed")
    for name, expected in members.items():
        path = ROOT / name
        if (not isinstance(name, str) or not re.fullmatch(r"[a-zA-Z0-9_/.-]{1,100}", name)
                or ".." in Path(name).parts or Path(name).is_absolute() or path.is_symlink()
                or not isinstance(expected, str) or not re.fullmatch(r"[a-f0-9]{64}", expected)
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected):
            raise RuntimeError("still_artifact_integrity_failure")
    encoded = json.dumps(members, sort_keys=True, separators=(",", ":")).encode()
    actual = hashlib.sha256(encoded).hexdigest()
    if actual != manifest["engine_artifact_sha256"]:
        raise RuntimeError("still_artifact_identity_invalid")
    return actual


ENGINE_ARTIFACT_SHA256 = verify_artifact()
