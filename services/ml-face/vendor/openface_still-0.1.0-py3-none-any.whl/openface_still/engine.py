"""Public still result v1 and caller-bound preprocessing over the one core."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path

import cv2
import numpy as np
import PIL

from .artifact import ENGINE_ARTIFACT_SHA256
from ._core.errors import PlatformError
from ._core.media import EvidenceFile
from ._core.vision import OpenCVEngine, decode_photo

CONTRACT_VERSION = "openface-still-v1"
MODEL_SHA256 = json.loads(Path(__file__).with_name("contract.json").read_bytes())["model_sha256"]
_LANDMARKS = ("right_eye", "left_eye", "nose", "mouth_right", "mouth_left")


@dataclass(frozen=True)
class StillImagePolicy:
    # Generic defaults remain unchanged. Consumers explicitly bind alternatives.
    max_encoded_bytes: int = 16 * 1024 * 1024
    max_decoded_pixels: int = 24_000_000
    max_faces: int = 64
    detector_score: float = .85
    detector_top_k: int = 1000
    decode_max_edge: int | None = 2400
    analysis_max_edge: int | None = 1600
    min_face_pixels: float = 32
    min_image_edge: int = 64
    clamp_boxes_before_alignment: bool = False

    def __post_init__(self):
        for name, low, high in (("max_encoded_bytes", 1, 20*1024*1024),
                               ("max_decoded_pixels", 1, 40_000_000), ("max_faces", 1, 100),
                               ("detector_top_k", 1, 1000), ("min_image_edge", 1, 4096)):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= high:
                raise ValueError("invalid_still_policy_" + name)
        for name in ("decode_max_edge", "analysis_max_edge"):
            value = getattr(self, name)
            if value is not None and (type(value) is not int or not 64 <= value <= 4096):
                raise ValueError("invalid_still_policy_" + name)
        for name, low, high in (("detector_score", 0.01, 1), ("min_face_pixels", 0, 4096)):
            value = getattr(self, name)
            if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
                raise ValueError("invalid_still_policy_" + name)
        if type(self.clamp_boxes_before_alignment) is not bool:
            raise ValueError("invalid_still_policy_clamping")


@dataclass(frozen=True)
class StillFace:
    bbox: dict[str, int]
    landmarks: dict[str, list[float]]
    confidence: float
    embedding: list[float]
    aligned_pixels: np.ndarray
    quality: float
    yaw_proxy: float


@dataclass(frozen=True)
class StillImageResult:
    width: int
    height: int
    faces: tuple[StillFace, ...]
    identity: dict


def _canonical_sha256(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


class StillImageEngine:
    def __init__(self, model_dir: str | Path, *, policy: StillImagePolicy, threads: int=1):
        if not isinstance(policy, StillImagePolicy) or type(threads) is not int or not 1 <= threads <= 4:
            raise ValueError("invalid_still_configuration")
        model_dir = Path(model_dir)
        manifest = json.loads((model_dir / "manifest.json").read_bytes())
        for name, expected in MODEL_SHA256.items():
            row = manifest["artifacts"][name]
            if (row.get("sha256") != expected or not isinstance(row.get("file"), str)
                    or Path(row["file"]).name != row["file"]):
                raise PlatformError("model_integrity_failure", 503)
        self.policy = policy
        self._engine = OpenCVEngine(model_dir, threads, policy.max_decoded_pixels,
                                   detector_score=policy.detector_score, detector_top_k=policy.detector_top_k)
        self.identity = {
            "contract_version": CONTRACT_VERSION,
            "model_version": self._engine.model_version,
            "engine_artifact_sha256": ENGINE_ARTIFACT_SHA256,
            "artifact_fingerprint": self._engine.artifact_fingerprint,
            "policy_sha256": _canonical_sha256(asdict(policy)),
            "model_sha256": dict(MODEL_SHA256),
            "runtime_versions": {"opencv": cv2.__version__, "numpy": np.__version__, "pillow": PIL.__version__},
        }
        self.identity["processing_fingerprint"] = _canonical_sha256(self.identity)

    def analyze(self, image_bytes: bytes | EvidenceFile, *, content_type: str) -> StillImageResult:
        if content_type not in ("image/jpeg", "image/png", "image/webp"):
            raise PlatformError("unsupported_image_type", 422)
        p = self.policy
        decoded = decode_photo(image_bytes, p.max_decoded_pixels, p.decode_max_edge,
                               max_encoded_bytes=p.max_encoded_bytes, min_image_edge=p.min_image_edge,
                               content_type=content_type)
        values = self._engine.extract(decoded.pixels, analysis_max_edge=p.analysis_max_edge,
                                      min_face_pixels=p.min_face_pixels, max_faces=p.max_faces,
                                      clamp_boxes_before_alignment=p.clamp_boxes_before_alignment)
        height, width = decoded.pixels.shape[:2]
        sx, sy = decoded.original_width / width, decoded.original_height / height
        faces = []
        for value in values:
            x, y, bw, bh = value.bbox
            left = max(0, min(decoded.original_width, math.floor(x*sx)))
            top = max(0, min(decoded.original_height, math.floor(y*sy)))
            right = max(0, min(decoded.original_width, math.ceil((x+bw)*sx)))
            bottom = max(0, min(decoded.original_height, math.ceil((y+bh)*sy)))
            if right <= left or bottom <= top:
                continue
            faces.append(StillFace(
                {"x": left, "y": top, "width": right-left, "height": bottom-top},
                {name: [point[0]*sx, point[1]*sy] for name, point in zip(_LANDMARKS, value.landmarks, strict=True)},
                value.confidence, value.embedding, value.aligned_pixels, value.quality, value.yaw_proxy))
        return StillImageResult(decoded.original_width, decoded.original_height, tuple(faces), dict(self.identity))
