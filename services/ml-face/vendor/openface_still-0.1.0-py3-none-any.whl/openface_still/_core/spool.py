"""Private request storage and lock-aware recovery of abandoned run directories.

The lease is held by the service and explicitly inherited by its inference children.
Cleanup never removes an active run. This is lifetime control, not disk encryption;
mount the directory on reviewed encrypted/ephemeral local storage in production.
"""
from __future__ import annotations

import fcntl
import os
from pathlib import Path
import stat
import tempfile
import uuid


class EvidenceStore:
    def __init__(self, root: Path | None = None, *, stale_after: float = 600):
        if not 0 < stale_after <= 86400:
            raise ValueError("invalid_evidence_retention")
        self.root = Path(root or Path(tempfile.gettempdir()) / f"ikanisa-face-evidence-{os.getuid()}")
        self.stale_after = stale_after
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        info = self.root.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
            raise ValueError("evidence_directory_must_be_private_owned_directory")
        self.root = self.root.resolve()
        from .evidence_cleanup import register_root, EvidenceSweeper
        import threading
        register_root(self.root)
        self._sweeper = EvidenceSweeper(self.root, stale_after=stale_after)
        self._sweep_lock = threading.Lock()
        self.directory = self.root / ("run-" + uuid.uuid4().hex)
        self.directory.mkdir(mode=0o700)
        self.lease_fd = os.open(self.directory / ".lease", os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        fcntl.flock(self.lease_fd, fcntl.LOCK_SH)
        self.closed = False
        self.last_sweep = {"removed_runs": 0, "skipped_runs": 0}

    def sweep(self, now: float | None = None, *, dry_run=False,
              max_runs=100, max_files=500, max_bytes=32*1024*1024):
        """Bounded fd-relative sweep. Dry run never removes or marks files."""
        if self.closed:
            return {"removed_runs": 0, "skipped_runs": 0, "dry_run": dry_run}
        with self._sweep_lock:
            result = self._sweeper.sweep(now=now, dry_run=dry_run,
                max_runs=max_runs, max_files=max_files, max_bytes=max_bytes)
            if not dry_run:
                self.last_sweep = result
            return result

    def close(self) -> None:
        if self.closed:
            return
        # Caller must close/reap every inference child before releasing this lease.
        self.closed = True
        with self._sweep_lock:
            self._sweeper.close()
        os.close(self.lease_fd)
        fd = None
        try:
            # Reopen: upgrading the inherited open-file-description's lock would
            # incorrectly consider a still-live child to be the same lock owner.
            fd = os.open(self.directory / ".lease", os.O_RDWR | os.O_NOFOLLOW)
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            # Mark only our generated, now-unlocked run as ready for bounded
            # cleanup. Never recursively remove unexpected files on shutdown.
            from .evidence_cleanup import GC_MARKER, EvidenceSweeper
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, GC_MARKER)
            os.ftruncate(fd, len(GC_MARKER))
            os.fsync(fd)
            os.close(fd); fd = None
            sweeper = EvidenceSweeper(self.root, stale_after=self.stale_after)
            try:
                sweeper.sweep(_run=self.directory.name)
            finally:
                sweeper.close()
        except OSError:
            # Retain locked/failed cleanup for the next maintenance sweep.
            pass
        finally:
            if fd is not None:
                os.close(fd)
