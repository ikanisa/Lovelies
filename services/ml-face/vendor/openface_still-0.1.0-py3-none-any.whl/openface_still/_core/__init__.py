"""Exact selected canonical primitives; no application initialization."""
