"""Resident POSIX inference processes with bounded JSON transport and deadlines.

Model execution and codec calls run in a child, separately from account/database work.
One child per enabled inference lane is reused. A failed/timed-out child is killed
and reaped; the failed request is NOT silently repeated. New requests may restart
it, but a different model identity requires a full service restart.

This is fault/lifetime isolation, not a hostile-code sandbox. Use OS/container
memory, CPU, network and filesystem limits as well. Process creation and kernel
uninterruptible I/O are outside a Python-level real-time guarantee.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import re
import selectors
import signal
import subprocess
import sys
import threading
import time
from typing import Sequence
import uuid

from .errors import PlatformError
from .media import local_evidence
from .spool import EvidenceStore
from .vision import Face

MAX_REQUEST = 8192
MAX_REPLY = 512 * 1024
_ERROR = re.compile(r"[a-z][a-z0-9_]{0,95}\Z")


def child_environment(threads: int) -> dict[str, str]:
    # Do not inherit FP_*, DB/password variables, proxies, cloud credentials or Python hooks.
    env = {"PATH": os.defpath, "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONPATH": str(Path(__file__).resolve().parents[1]),
           "OPENBLAS_NUM_THREADS": str(threads), "OMP_NUM_THREADS": str(threads),
           "MKL_NUM_THREADS": str(threads), "NUMEXPR_NUM_THREADS": str(threads)}
    for key in ("LANG", "LC_ALL", "SYSTEMROOT"):
        if key in os.environ:
            env[key] = os.environ[key]
    return env


def _json(raw: bytes) -> dict:
    def invalid_constant(_):
        raise ValueError("nonfinite_json")
    def unique(items):
        result = {}
        for key, item in items:
            if key in result:
                raise ValueError("duplicate_json_key")
            result[key] = item
        return result
    value = json.loads(raw, parse_constant=invalid_constant, object_pairs_hook=unique)
    if not isinstance(value, dict):
        raise ValueError("json_object_required")
    return value


class WorkerChannel:
    """One serial, reusable child. argv injection exists for private unit tests only."""
    max_request = MAX_REQUEST
    max_reply = MAX_REPLY
    allowed_operations = ("photo", "video", "ping")
    def __init__(self, config: dict, *, timeout: float, boot_timeout: float,
                 lease_fd: int, argv: Sequence[str] | None = None):
        if os.name != "posix":
            raise ValueError("inference_supervision_requires_posix")
        for value in (timeout, boot_timeout):
            if not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= 120:
                raise ValueError("invalid_inference_deadline")
        self.config = dict(config)
        self.timeout, self.boot_timeout, self.lease_fd = timeout, boot_timeout, lease_fd
        self.argv = list(argv or [sys.executable, "-m", "face_platform.inference_worker"])
        self.process: subprocess.Popen | None = None
        self.metadata: dict | None = None
        self._lock = threading.Lock()
        self._closed = False
        self._unreaped: subprocess.Popen | None = None
        self.counters = {"starts": 0, "completed": 0, "timeouts": 0, "crashes": 0,
                         "protocol_errors": 0, "busy": 0}

    def _remaining(self, deadline: float) -> float:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise PlatformError("inference_timeout", 504)
        return remaining

    def _exchange(self, value: dict, deadline: float) -> dict:
        proc = self.process
        if proc is None or proc.stdin is None or proc.stdout is None:
            raise PlatformError("inference_worker_unavailable", 503)
        request_id = uuid.uuid4().hex
        payload = (json.dumps({"id": request_id, **value}, allow_nan=False,
                              separators=(",", ":")) + "\n").encode()
        if len(payload) > self.max_request:
            raise PlatformError("inference_request_invalid", 503)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(proc.stdin, selectors.EVENT_WRITE)
                sent = 0
                while sent < len(payload):
                    if not selector.select(self._remaining(deadline)):
                        raise PlatformError("inference_timeout", 504)
                    try:
                        sent += os.write(proc.stdin.fileno(), payload[sent:])
                    except BlockingIOError:
                        continue
                selector.unregister(proc.stdin)
                selector.register(proc.stdout, selectors.EVENT_READ)
                raw = bytearray()
                while True:
                    if not selector.select(self._remaining(deadline)):
                        raise PlatformError("inference_timeout", 504)
                    try:
                        data = os.read(proc.stdout.fileno(), min(65536, self.max_reply + 1 - len(raw)))
                    except BlockingIOError:
                        continue
                    if not data:
                        raise PlatformError("inference_worker_failed", 503)
                    raw.extend(data)
                    if len(raw) > self.max_reply:
                        raise ValueError("reply_too_large")
                    if b"\n" in raw:
                        line, tail = bytes(raw).split(b"\n", 1)
                        if tail:
                            raise ValueError("extra_reply_data")
                        response = _json(line)
                        if response.get("id") != request_id or type(response.get("ok")) is not bool:
                            raise ValueError("response_binding_mismatch")
                        if not response["ok"]:
                            code, status = response.get("error"), response.get("status")
                            if not isinstance(code, str) or not _ERROR.fullmatch(code) or type(status) is not int or not 400 <= status <= 599:
                                raise ValueError("invalid_worker_error")
                            raise PlatformError(code, status)
                        if set(response) != {"id", "ok", "result"} or not isinstance(response["result"], dict):
                            raise ValueError("invalid_reply")
                        return response["result"]
        except (BrokenPipeError, ConnectionError, OSError) as exc:
            raise PlatformError("inference_worker_failed", 503) from exc
        except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
            raise PlatformError("inference_protocol_error", 503) from exc

    def _stop(self) -> None:
        proc, self.process = self.process or self._unreaped, None
        if proc is None:
            return
        # Preserve ownership before attempting a signal: permission/OS errors
        # are not evidence that the process has stopped or been reaped.
        self._unreaped = proc
        try:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                # Still attempt bounded reaping and close both pipes. Preserve
                # the original inference failure instead of replacing it with
                # a cleanup exception (which may contain system details).
                pass
        finally:
            try:
                proc.wait(timeout=1)
            except (subprocess.TimeoutExpired, OSError):
                pass
            else:
                self._unreaped = None
            finally:
                for pipe in (proc.stdin, proc.stdout):
                    if pipe is not None:
                        try:
                            pipe.close()
                        except OSError:
                            pass

    def _start(self, deadline: float) -> None:
        if self._closed:
            raise PlatformError("inference_runtime_closed", 503)
        if self._unreaped is not None:
            if self._unreaped.poll() is None:
                raise PlatformError("inference_worker_unreaped", 503)
            self._unreaped.wait()
            self._unreaped = None
        if self.process is not None and self.process.poll() is None:
            return
        self._stop()
        if self._unreaped is not None:
            raise PlatformError("inference_worker_unreaped", 503)
        self.process = subprocess.Popen(self.argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, env=self._child_environment(),
            bufsize=0, close_fds=True, pass_fds=(self.lease_fd,), start_new_session=True)
        os.set_blocking(self.process.stdin.fileno(), False)
        os.set_blocking(self.process.stdout.fileno(), False)
        self.counters["starts"] += 1
        incoming = self._exchange({"op": "initialize", "config": self.config}, deadline)
        self._validate_metadata(incoming)
        if self.metadata is not None and incoming != self.metadata:
            raise PlatformError("inference_model_changed_restart_required", 503)
        self.metadata = incoming

    def _validate_metadata(self, incoming: dict) -> None:
        _validate_metadata(incoming)

    def _child_environment(self) -> dict[str, str]:
        return child_environment(self.config["threads"])

    def initialize(self) -> dict:
        with self._lock:
            try:
                self._start(time.monotonic() + self.boot_timeout)
            except BaseException:
                self._stop()
                raise
            return dict(self.metadata)

    def call(self, op: str, body: dict) -> dict:
        if op not in self.allowed_operations:
            raise ValueError("invalid_inference_operation")
        deadline = time.monotonic() + self.timeout
        if not self._lock.acquire(timeout=self.timeout):
            self.counters["busy"] += 1
            raise PlatformError("inference_busy", 429)
        try:
            self._start(deadline)
            result = self._exchange({"op": op, **body}, deadline)
            self.counters["completed"] += 1
            return result
        except PlatformError as exc:
            if exc.status >= 500:
                key = "timeouts" if exc.code == "inference_timeout" else (
                    "protocol_errors" if exc.code == "inference_protocol_error" else "crashes")
                self.counters[key] += 1
                self._stop()
            raise
        except BaseException:
            self._stop()
            raise
        finally:
            self._lock.release()

    def close(self) -> None:
        with self._lock:
            self._closed = True
            self._stop()

    def probe(self) -> str:
        # Busy is not unhealthy: its in-flight call has its own enforced deadline.
        if not self._lock.acquire(blocking=False):
            return "ready" if self.process is not None and self.process.poll() is None else "inference_worker_unavailable"
        try:
            deadline = time.monotonic() + self.boot_timeout
            self._start(deadline)
            if self._exchange({"op": "ping"}, deadline) != {"ready": True}:
                raise PlatformError("inference_protocol_error", 503)
            return "ready"
        except PlatformError as exc:
            self._stop()
            return exc.code
        finally:
            self._lock.release()

    def status(self) -> dict:
        return {"state": "closed" if self._closed else (
            "running" if self.process is not None and self.process.poll() is None else "not_running"),
            **self.counters}


def _validate_metadata(value: dict) -> None:
    if set(value) != {"model_version", "artifact_fingerprint", "pad"}:
        raise PlatformError("inference_protocol_error", 503)
    if not isinstance(value["model_version"], str) or not 1 <= len(value["model_version"]) <= 128:
        raise PlatformError("inference_protocol_error", 503)
    if not re.fullmatch(r"[a-f0-9]{64}", str(value["artifact_fingerprint"])):
        raise PlatformError("inference_protocol_error", 503)
    pad = value["pad"]
    if (not isinstance(pad, dict) or set(pad) != {"ready", "calibrated", "unavailable", "artifact_fingerprint"}
            or type(pad["ready"]) is not bool or type(pad["calibrated"]) is not bool
            or not isinstance(pad["unavailable"], str) or len(pad["unavailable"]) > 96
            or (pad["artifact_fingerprint"] is not None and not re.fullmatch(r"[a-f0-9]{64}", str(pad["artifact_fingerprint"])))):
        raise PlatformError("inference_protocol_error", 503)
    if pad["ready"] and not pad["artifact_fingerprint"]:
        raise PlatformError("inference_protocol_error", 503)


def _numbers(values, count: int, minimum=-float("inf"), maximum=float("inf")) -> list[float]:
    if (not isinstance(values, list) or len(values) != count or
            any(type(v) not in (int, float) or not math.isfinite(v) or not minimum <= v <= maximum for v in values)):
        raise PlatformError("inference_output_invalid", 503)
    return values


def _embedding(value) -> list[float]:
    result = _numbers(value, 128, -1.001, 1.001)
    if not 0.99 <= sum(v*v for v in result) <= 1.01:
        raise PlatformError("inference_output_invalid", 503)
    return result


class EngineProxy:
    def __init__(self, owner):
        self.owner = owner
        self.model_version = owner.metadata["model_version"]
        self.artifact_fingerprint = owner.metadata["artifact_fingerprint"]

    def photo(self, source) -> list[Face]:
        result = self.owner.execute("photo", source)
        faces = result.get("faces")
        if set(result) != {"faces"} or not isinstance(faces, list) or len(faces) > 64:
            raise PlatformError("inference_output_invalid", 503)
        out = []
        for face in faces:
            if not isinstance(face, dict) or set(face) != {"bbox", "landmarks", "embedding", "quality", "yaw_proxy"}:
                raise PlatformError("inference_output_invalid", 503)
            bbox = _numbers(face["bbox"], 4)
            if bbox[2] <= 0 or bbox[3] <= 0:
                raise PlatformError("inference_output_invalid", 503)
            landmarks = face["landmarks"]
            if not isinstance(landmarks, list) or len(landmarks) != 5:
                raise PlatformError("inference_output_invalid", 503)
            landmarks = [_numbers(p, 2) for p in landmarks]
            quality = _numbers([face["quality"]], 1, 0, 1)[0]
            yaw = _numbers([face["yaw_proxy"]], 1)[0]
            out.append(Face(bbox, landmarks, _embedding(face["embedding"]), quality, yaw))
        return out


class PadProxy:
    def __init__(self, owner):
        self.owner = owner
        self.ready = owner.metadata["pad"]["ready"]
        self.calibrated = owner.metadata["pad"]["calibrated"]
        self.unavailable = owner.metadata["pad"]["unavailable"]
        self.artifact_fingerprint = owner.metadata["pad"]["artifact_fingerprint"]

    def evaluate(self, source, engine, policy) -> dict:
        if not self.ready:
            raise PlatformError(self.unavailable, 503)
        result = self.owner.execute("video", source, {
            "consistency_threshold": policy.consistency_threshold,
            "liveness_threshold": policy.liveness_threshold})
        if (set(result) != {"model_version", "embeddings", "qualities", "liveness", "pad_score", "usable_frames"}
                or result["model_version"] != engine.model_version or result["liveness"] != "passive_passed"
                or type(result["usable_frames"]) is not int or not 6 <= result["usable_frames"] <= 12
                or not isinstance(result["embeddings"], list) or len(result["embeddings"]) != 3):
            raise PlatformError("inference_output_invalid", 503)
        for value in result["embeddings"]:
            _embedding(value)
        _numbers(result["qualities"], 3, 0, 1)
        _numbers([result["pad_score"]], 1, 0, 1)
        if result["pad_score"] < policy.liveness_threshold:
            raise PlatformError("inference_output_invalid", 503)
        return result


class InferenceRuntime:
    def __init__(self, settings, store: EvidenceStore):
        self.store, self.settings = store, settings
        self.channels: dict[str, WorkerChannel] = {}
        auth = any("auth_passive" in p.modes for p in settings.apps.values())
        config = {"model_dir": str(settings.model_dir.resolve()), "threads": settings.inference_threads,
                  "max_photo_pixels": settings.max_photo_pixels, "evidence_dir": str(store.directory),
                  "max_body_bytes": settings.max_body_bytes, "parent_pid": os.getpid(), "load_pad": auth}
        for lane in (("photo", "video") if auth else ("photo",)):
            self.channels[lane] = WorkerChannel({**config, "load_pad": lane == "video"},
                timeout=settings.inference_timeout, boot_timeout=settings.inference_boot_timeout,
                lease_fd=store.lease_fd)
        initial = "video" if auth else "photo"
        try:
            self.metadata = self.channels[initial].initialize()
        except BaseException:
            self.close()
            raise
        # A lazily started photo child must carry the same recognition identity.
        for lane, channel in self.channels.items():
            if lane != initial:
                channel.metadata = {**self.metadata, "pad": {"ready": False, "calibrated": False,
                    "unavailable": "pad_not_enabled", "artifact_fingerprint": None}}
        self.engine, self.pad = EngineProxy(self), PadProxy(self)

    def execute(self, op, source, policy=None):
        if op not in self.channels:
            raise PlatformError("feature_not_enabled", 403)
        with local_evidence(source, limit=self.settings.max_body_bytes,
                            directory=str(self.store.directory)) as evidence:
            body = {"evidence": {"path": str(evidence.path.resolve()),
                    "size": evidence.size, "sha256": evidence.sha256}}
            if policy is not None:
                body["policy"] = policy
            return self.channels[op].call(op, body)

    def probe(self, feature):
        lane = "photo" if feature == "photo" else "video"
        return self.channels[lane].probe() if lane in self.channels else "feature_not_enabled"

    def status(self):
        return {lane: channel.status() for lane, channel in self.channels.items()}

    def close(self):
        for channel in self.channels.values():
            channel.close()
