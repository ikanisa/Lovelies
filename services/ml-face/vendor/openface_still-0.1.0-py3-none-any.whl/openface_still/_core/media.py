"""Bounded, request-owned media with no whole-upload copy in application RAM.

Only the server constructs EvidenceFile. A caller cannot supply a filesystem path
or a content hash through the wire API. Files are private and deleted on close.
Temporary storage must be encrypted/ephemeral in the deployment environment.
"""
from __future__ import annotations

import asyncio
from contextlib import contextmanager
import hashlib
from pathlib import Path
import tempfile
from threading import BoundedSemaphore
from typing import Iterator

from .errors import PlatformError


class EvidenceFile:
    def __init__(self, *, limit: int, suffix: str = ".bin", directory: str | None = None):
        self.limit = limit
        self._file = tempfile.NamedTemporaryFile(prefix="fp-evidence-", suffix=suffix,
                                                 dir=directory, delete=False)
        self.path = Path(self._file.name)
        self.size = 0
        self._hash = hashlib.sha256()
        self._sealed = False
        self._closed = False
        self._owns_path = True

    def write(self, chunk: bytes) -> None:
        if self._sealed or self._closed:
            raise RuntimeError("evidence_not_writable")
        if self.size + len(chunk) > self.limit:
            raise PlatformError("body_too_large", 413)
        self._file.write(chunk)
        self._hash.update(chunk)
        self.size += len(chunk)

    def seal(self) -> None:
        if self._closed:
            raise RuntimeError("evidence_closed")
        if not self.size:
            raise PlatformError("empty_media", 422)
        self._file.flush()
        self._file.close()
        self._sealed = True

    @property
    def sha256(self) -> str:
        if not self._sealed or self._closed:
            raise RuntimeError("evidence_not_sealed")
        return self._hash.hexdigest()

    def __len__(self) -> int:
        return self.size

    def close(self) -> None:
        if not self._closed:
            self._file.close()
            if self._owns_path:
                self.path.unlink(missing_ok=True)
            self._closed = True

    def __enter__(self) -> EvidenceFile:
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    @classmethod
    def borrow(cls, reference: dict, *, root: Path, limit: int) -> EvidenceFile:
        """Child-only, read-only attachment to a sealed server-owned evidence file.

        No HTTP request can provide a filesystem reference. Verify bytes without
        materializing them; never unlink the parent's file on child completion.
        """
        import os
        import re
        import stat
        if (type(reference.get('size')) is not int or not 0 < reference['size'] <= limit
                or not isinstance(reference.get('path'), str)
                or not re.fullmatch(r'[a-f0-9]{64}', str(reference.get('sha256')))):
            raise PlatformError('evidence_reference_invalid', 503)
        path = Path(reference['path'])
        if (path.parent.resolve() != root.resolve() or not path.name.startswith('fp-evidence-')
                or path.is_symlink()):
            raise PlatformError('evidence_reference_invalid', 503)
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        source = os.fdopen(fd, 'rb')
        try:
            info = os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or info.st_nlink != 1 or info.st_mode & 0o077 or info.st_size != reference['size']):
                raise PlatformError('evidence_reference_invalid', 503)
            digest = hashlib.sha256()
            for chunk in iter(lambda: source.read(65536), b''):
                digest.update(chunk)
            if digest.hexdigest() != reference['sha256']:
                raise PlatformError('evidence_integrity_failure', 503)
            source.seek(0)
            obj = cls.__new__(cls)
            obj.limit, obj.path, obj.size = limit, path, info.st_size
            obj._file, obj._hash = source, digest
            obj._sealed, obj._closed, obj._owns_path = True, False, False
            return obj
        except BaseException:
            source.close()
            raise

    @classmethod
    async def receive(cls, request, *, limit: int, timeout: float, suffix: str = ".bin",
                      directory: str | None = None) -> EvidenceFile:
        # HTTP is optional for account-free still consumers of EvidenceFile.
        from starlette.requests import ClientDisconnect
        declared = getattr(request, 'headers', {}).get('content-length')
        expected = None
        if declared is not None:
            if len(declared) > 20 or not declared.isascii() or not declared.isdigit():
                raise PlatformError('invalid_content_length', 400)
            expected = int(declared)
            if expected > limit:
                raise PlatformError('body_too_large', 413)
        evidence = cls(limit=limit, suffix=suffix, directory=directory)
        try:
            async with asyncio.timeout(timeout):
                async for chunk in request.stream():
                    # ASGI can supply a large chunk; no concatenation/second bytes copy.
                    evidence.write(chunk)
            if expected is not None and evidence.size != expected:
                raise PlatformError('content_length_mismatch', 400)
            evidence.seal()
            return evidence
        except ClientDisconnect as exc:
            evidence.close()
            raise PlatformError('upload_disconnected', 400) from exc
        except TimeoutError as exc:
            evidence.close()
            raise PlatformError("upload_timeout", 408) from exc
        except BaseException:
            # Includes disconnect/cancellation, not just ordinary exceptions.
            evidence.close()
            raise


@contextmanager
def local_evidence(source: bytes | EvidenceFile, *, limit: int = 16 * 1024 * 1024,
                   suffix: str = ".mp4", directory: str | None = None) -> Iterator[EvidenceFile]:
    """Backward-compatible bytes entry for tests/tools; HTTP uses EvidenceFile."""
    if isinstance(source, EvidenceFile):
        source.sha256  # Validate sealed, live lifetime; do not delete caller-owned file.
        if source.size > limit:
            raise PlatformError("body_too_large", 413)
        yield source
        return
    if not isinstance(source, bytes):
        raise PlatformError("invalid_media_source", 422)
    with EvidenceFile(limit=limit, suffix=suffix, directory=directory) as evidence:
        evidence.write(source)
        evidence.seal()
        yield evidence


class WorkBudget:
    """Fail-fast admission, including upload lifetime; not a task queue.

    HTTP admission includes upload time. The default server runtime additionally
    delegates model/codec work to resident supervised child processes. Limits
    remain per service process, not distributed fleet capacity guarantees.
    """
    def __init__(self, capacity: int):
        if type(capacity) is not int or not 1 <= capacity <= 8:
            raise ValueError("invalid_work_capacity")
        self._slots = BoundedSemaphore(capacity)

    @contextmanager
    def slot(self):
        if not self._slots.acquire(blocking=False):
            raise PlatformError("inference_busy", 429)
        try:
            yield
        finally:
            self._slots.release()
