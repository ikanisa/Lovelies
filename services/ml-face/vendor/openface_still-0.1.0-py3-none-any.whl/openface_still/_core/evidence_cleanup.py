"""Bounded cleanup of private, generated evidence runs only.

Never recursively deletes a directory or follows a link. Only known temporary
filenames in registered evidence roots are unlinked under an exclusive run lease.
Partial filesystem progress survives interruption; a lease marker allows the next
sweep to continue without resetting the age delay after each removed file.
"""
from __future__ import annotations

import fcntl
import math
import os
from pathlib import Path
import re
import stat
import time
from types import SimpleNamespace

ROOT_MARKER = b'IKANISA_FACE_EVIDENCE_ROOT_V1\n'
GC_MARKER = b'IKANISA_FACE_EVIDENCE_GC_V1\n'
RUN_NAME = re.compile(r'run-[a-f0-9]{32}\Z')
FILE_NAME = re.compile(r'fp-evidence-[A-Za-z0-9_.-]{1,160}\Z')


def _owned_directory(info):
    return stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and not info.st_mode & 0o077


def register_root(root: Path):
    """Used only by explicitly configured service startup, not by dry-run CLI."""
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        if not _owned_directory(os.fstat(fd)):
            raise ValueError('evidence_root_must_be_private')
        try:
            marker = os.open('.fp-evidence-root', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
        except FileExistsError:
            return
        try:
            os.write(marker, ROOT_MARKER); os.fsync(marker)
        finally:
            os.close(marker)
    finally:
        os.close(fd)


class EvidenceSweeper:
    def __init__(self, root: Path, *, stale_after=600):
        if type(stale_after) not in (int, float) or not math.isfinite(stale_after) or not 0 < stale_after <= 86400:
            raise ValueError('invalid_evidence_retention')
        self.root = Path(root)
        self.stale_after = stale_after
        self.root_fd = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        self.scans = {}
        try:
            if not _owned_directory(os.fstat(self.root_fd)):
                raise ValueError('evidence_root_must_be_private')
            marker = os.open('.fp-evidence-root', os.O_RDONLY | os.O_NOFOLLOW, dir_fd=self.root_fd)
            try:
                info = os.fstat(marker)
                if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid()
                        or os.read(marker, 128) != ROOT_MARKER):
                    raise ValueError('evidence_root_not_registered')
            finally:
                os.close(marker)
        except BaseException:
            os.close(self.root_fd); self.root_fd = -1; raise

    def close(self):
        for scan in self.scans.values():
            scan.close()
        self.scans.clear()
        if self.root_fd >= 0:
            os.close(self.root_fd); self.root_fd = -1

    def sweep(self, *, now=None, dry_run=False, max_runs=100, max_files=500, max_bytes=32*1024*1024, _run=None):
        if type(dry_run) is not bool:
            raise ValueError('invalid_cleanup_mode')
        for value, maximum in ((max_runs, 500), (max_files, 2000), (max_bytes, 64*1024*1024)):
            if type(value) is not int or not 1 <= value <= maximum:
                raise ValueError('invalid_evidence_cleanup_budget')
        now = time.time() if now is None else now
        if type(now) not in (int, float) or not math.isfinite(now) or now < 0:
            raise ValueError('invalid_cleanup_clock')
        result = dict(dry_run=dry_run, scanned_entries=0, scanned_runs=0, scanned_files=0, eligible_files=0,
                      eligible_bytes=0, removed_files=0, removed_bytes=0, removed_runs=0,
                      skipped_runs=0, protected_runs=0, unexpected_entries=0, more=False)
        if self.root_fd < 0:
            return result
        # Hold an iterator across calls; new processes rescan safely from the start.
        # A fresh pass is needed to discover entries added during directory iteration.
        if _run is not None:
            if not isinstance(_run, str) or not RUN_NAME.fullmatch(_run):
                raise ValueError('invalid_generated_evidence_run')
            scan = iter((SimpleNamespace(name=_run),))
        else:
            scan = self.scans.get(dry_run)
            if scan is None:
                scan = self.scans[dry_run] = os.scandir(self.root_fd)
        while (result['scanned_runs'] < max_runs and result['scanned_files'] < max_files
               and result['scanned_entries'] < max_runs*4+1):
            try:
                entry = next(scan)
            except StopIteration:
                if _run is None:
                    scan.close(); del self.scans[dry_run]
                return result
            result['scanned_entries'] += 1
            if not RUN_NAME.fullmatch(entry.name):
                continue
            result['scanned_runs'] += 1
            run_fd = lease_fd = None
            try:
                run_fd = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=self.root_fd)
                info = os.fstat(run_fd)
                if not _owned_directory(info):
                    result['skipped_runs'] += 1; continue
                try:
                    lease_fd = os.open('.lease', os.O_RDWR | os.O_NOFOLLOW, dir_fd=run_fd)
                except FileNotFoundError:
                    # Recover a crash between removing the lease and rmdir, only
                    # for an EMPTY old generated directory. No recursive fallback.
                    with os.scandir(run_fd) as children:
                        empty = next(children, None) is None
                    if empty and now-info.st_mtime >= self.stale_after and not dry_run:
                        os.rmdir(entry.name, dir_fd=self.root_fd); result['removed_runs'] += 1
                    else:
                        result['skipped_runs'] += 1
                    continue
                lease = os.fstat(lease_fd)
                if not stat.S_ISREG(lease.st_mode) or lease.st_uid != os.getuid() or lease.st_nlink != 1:
                    result['skipped_runs'] += 1; continue
                try:
                    fcntl.flock(lease_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    result['protected_runs'] += 1; result['skipped_runs'] += 1; continue
                marker = os.read(lease_fd, 128)
                if marker not in (b'', GC_MARKER):
                    result['unexpected_entries'] += 1; result['skipped_runs'] += 1; continue
                if marker != GC_MARKER and now-info.st_mtime < self.stale_after:
                    result['skipped_runs'] += 1; continue
                marked = marker == GC_MARKER
                with os.scandir(run_fd) as children:
                    for child in children:
                        if result['scanned_files'] >= max_files:
                            result['more'] = True; break
                        if child.name == '.lease':
                            continue
                        result['scanned_files'] += 1
                        item = os.stat(child.name, dir_fd=run_fd, follow_symlinks=False)
                        if (not FILE_NAME.fullmatch(child.name) or not stat.S_ISREG(item.st_mode)
                                or item.st_nlink != 1 or item.st_uid != os.getuid()):
                            result['unexpected_entries'] += 1; continue
                        if result['eligible_bytes'] + item.st_size > max_bytes:
                            result['more'] = True; continue
                        result['eligible_files'] += 1; result['eligible_bytes'] += item.st_size
                        if dry_run:
                            continue
                        if not marked:
                            os.lseek(lease_fd, 0, os.SEEK_SET); os.write(lease_fd, GC_MARKER)
                            os.ftruncate(lease_fd, len(GC_MARKER)); os.fsync(lease_fd); marked = True
                        fresh = os.stat(child.name, dir_fd=run_fd, follow_symlinks=False)
                        if (fresh.st_dev, fresh.st_ino, fresh.st_size, fresh.st_nlink) != (item.st_dev, item.st_ino, item.st_size, 1):
                            result['unexpected_entries'] += 1; continue
                        os.unlink(child.name, dir_fd=run_fd)
                        result['removed_files'] += 1; result['removed_bytes'] += item.st_size
                # Only remove the lease and EMPTY directory, never unknown files.
                if not dry_run and result['scanned_files'] < max_files:
                    with os.scandir(run_fd) as remaining:
                        only_lease = all(e.name == '.lease' for e in remaining)
                    if only_lease:
                        current = os.stat(entry.name, dir_fd=self.root_fd, follow_symlinks=False)
                        if (current.st_dev, current.st_ino) == (info.st_dev, info.st_ino):
                            os.unlink('.lease', dir_fd=run_fd)
                            result['scanned_files'] += 1
                            os.rmdir(entry.name, dir_fd=self.root_fd); result['removed_runs'] += 1
            except OSError:
                result['skipped_runs'] += 1
            finally:
                if lease_fd is not None:
                    os.close(lease_fd)
                if run_fd is not None:
                    os.close(run_fd)
        result['more'] = True
        return result
