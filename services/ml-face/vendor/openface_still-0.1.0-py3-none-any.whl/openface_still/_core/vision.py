"""Bounded image decoding and OpenCV reference pipeline.
One worker object owns its OpenCV instances. Calls are serialized because
setInputSize and DNN forward mutate internal state. Replicate worker processes
for independent inference lanes, rather than sharing a Net concurrently.
"""
from pathlib import Path
from threading import Lock
from dataclasses import dataclass
import io, hashlib, json, warnings
import cv2
import numpy as np
from PIL import Image, ImageOps
from .errors import PlatformError
from .media import EvidenceFile

MODEL_VERSION="opencv-yunet-sface-2021dec-v1"
DIMENSIONS=128

@dataclass
class Face:
    bbox: list[float]
    landmarks: list[list[float]]
    embedding: list[float]
    quality: float
    yaw_proxy: float


@dataclass(frozen=True)
class DecodedImage:
    pixels: np.ndarray
    original_width: int
    original_height: int


@dataclass(frozen=True)
class ImageFace:
    """Versioned primitive result; pixels are owned uint8, upright aligned BGR.

    Coordinates/landmarks describe the supplied upright analysis image. This
    result carries no account, candidate, consent or authorization semantics.
    """
    bbox: list[float]
    landmarks: list[list[float]]
    confidence: float
    embedding: list[float]
    aligned_pixels: np.ndarray
    quality: float
    yaw_proxy: float


def decode_photo(source: bytes | EvidenceFile, max_pixels: int = 24_000_000,
                 max_edge: int | None = 2400, *, max_encoded_bytes: int = 16 * 1024 * 1024,
                 min_image_edge: int = 64, content_type: str | None = None) -> DecodedImage:
    if len(source) > max_encoded_bytes:
        raise PlatformError("image_too_large", 413)
    if max_edge is not None and (type(max_edge) is not int or not 64 <= max_edge <= 4096):
        raise ValueError("invalid_decode_edge")
    try:
        if isinstance(source, EvidenceFile):
            source.sha256
            handle = source.path
        elif isinstance(source, bytes):
            handle = io.BytesIO(source)
        else:
            raise ValueError("source")
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(handle) as im:
                if im.format not in ("JPEG", "PNG", "WEBP"):
                    raise ValueError("format")
                expected_type = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}[im.format]
                if content_type is not None and content_type != expected_type:
                    raise PlatformError("image_content_type_mismatch", 422)
                if im.width * im.height > max_pixels or min(im.size) < min_image_edge:
                    raise ValueError("size")
                if getattr(im, "n_frames", 1) != 1:
                    raise ValueError("animated")
                original_w, original_h = im.size
                if im.getexif().get(274, 1) in (5, 6, 7, 8):
                    original_w, original_h = original_h, original_w
                # JPEG draft requests decoder downsampling before RGB allocation.
                # PNG/WebP may still allocate up to max_pixels in their decoders.
                if im.format == "JPEG" and max_edge is not None:
                    # Request a native 1/2, 1/4 or 1/8 decode whenever needed.
                    # Asking draft for 2400x2400 on a 4000px image selects no
                    # decoder reduction; a later thumbnail wastes a full bitmap.
                    factor = 1
                    while max(im.size) / factor > max_edge and factor < 8:
                        factor *= 2
                    im.draft("RGB", (max(1, im.width // factor), max(1, im.height // factor)))
                oriented = ImageOps.exif_transpose(im)
                if max_edge is not None:
                    oriented.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
                rgb = oriented.convert("RGB")
                pixels = cv2.cvtColor(np.asarray(rgb), cv2.COLOR_RGB2BGR)
                return DecodedImage(pixels, original_w, original_h)
    except PlatformError:
        raise
    except Exception as exc:
        raise PlatformError("invalid_image", 422) from exc


def decode_image(source: bytes | EvidenceFile, max_pixels: int = 24_000_000) -> np.ndarray:
    """Compatibility helper; photo() remaps coordinates to original orientation."""
    return decode_photo(source, max_pixels).pixels


def cosine(a,b) -> float:
    aa=np.asarray(a,dtype=np.float32)
    bb=np.asarray(b,dtype=np.float32)
    if aa.shape!=(DIMENSIONS,) or bb.shape!=(DIMENSIONS,) or not np.isfinite(aa).all() or not np.isfinite(bb).all():
        raise PlatformError("invalid_embedding")
    d=float(np.linalg.norm(aa)*np.linalg.norm(bb))
    if d<1e-8:
        raise PlatformError("zero_embedding")
    return float(np.clip(np.dot(aa,bb)/d,-1,1))


def check_consistency(embeddings,threshold: float):
    if len(embeddings)<1:
        raise PlatformError("no_usable_frames")
    for i,a in enumerate(embeddings):
        for b in embeddings[i+1:]:
            if cosine(a,b)<threshold:
                raise PlatformError("identity_inconsistent",422)


def quality(image: np.ndarray,row) -> float:
    h,w=image.shape[:2]
    x,y,bw,bh=row[:4]
    crop=image[max(0,int(y)):min(h,int(y+bh)),max(0,int(x)):min(w,int(x+bw))]
    if crop.size==0:
        return 0.0
    gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
    blur=float(cv2.Laplacian(gray,cv2.CV_32F).var())
    light=float(gray.mean())
    detail=min(1.,blur/120.)
    exposure=max(0.,1.-abs(light-128.)/128.)
    size=min(1.,min(bw,bh)/110.)
    return float(np.clip(.4*detail+.3*exposure+.3*size,0,1))

class OpenCVEngine:
    model_version=MODEL_VERSION
    dimensions=DIMENSIONS
    def __init__(self,model_dir: Path,threads: int=2, max_photo_pixels: int=24_000_000,
                 *, detector_score: float=.85, detector_top_k: int=1000):
        self.model_dir=Path(model_dir)
        self.max_photo_pixels=max_photo_pixels
        self.lock=Lock()
        manifest_bytes=(self.model_dir/"manifest.json").read_bytes()
        manifest=json.loads(manifest_bytes)
        self.artifact_fingerprint=hashlib.sha256(manifest_bytes).hexdigest()
        for key in ("yunet","sface"):
            rec=manifest["artifacts"][key]
            p=self.model_dir/rec["file"]
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=rec["sha256"]:
                raise PlatformError("model_integrity_failure",503)
        cv2.setNumThreads(threads)
        cv2.ocl.setUseOpenCL(False)
        self.detector=cv2.FaceDetectorYN_create(str(self.model_dir/manifest["artifacts"]["yunet"]["file"]),"",(320,320),detector_score,.3,detector_top_k)
        self.recognizer=cv2.FaceRecognizerSF_create(str(self.model_dir/manifest["artifacts"]["sface"]["file"]),"")

    def analyze(self,image: np.ndarray,all_faces: bool=False) -> list[Face]:
        return [Face(value.bbox, value.landmarks, value.embedding, value.quality, value.yaw_proxy)
                for value in self.extract(image, all_faces=all_faces,
                    analysis_max_edge=1600 if all_faces else 720,
                    min_face_pixels=32, max_faces=64)]

    def extract(self, image: np.ndarray, *, all_faces: bool=True,
                analysis_max_edge: int | None=None, min_face_pixels: float=0,
                max_faces: int=100, clamp_boxes_before_alignment: bool=False) -> list[ImageFace]:
        """Public still primitive API v1, sharing the resident detector/recognizer.

        Generic analyze/photo retain their prior resize, minimum-face and count
        defaults. Independent consumers must bind their explicit policy and
        complete preprocessing identity before comparing stored references.
        """
        with self.lock:
            original_h,original_w=image.shape[:2]
            scale=min(1.,analysis_max_edge/max(original_w,original_h)) if analysis_max_edge else 1.
            work=cv2.resize(image,(max(1,round(original_w*scale)),max(1,round(original_h*scale)))) if scale<1 else image
            hh,ww=work.shape[:2]
            self.detector.setInputSize((ww,hh))
            _,rows=self.detector.detect(work)
            if rows is None:
                return []
            if not all_faces and len(rows)!=1:
                raise PlatformError("multiple_faces",422)
            if len(rows)>max_faces:
                raise PlatformError("too_many_faces",422)
            output=[]
            for row in rows:
                row=row.astype(np.float32).copy()
                if (row.shape != (15,) or not np.isfinite(row).all()
                        or min(row[2],row[3]) <= 0 or not 0 <= row[14] <= 1):
                    continue
                row[:14]/=scale
                if min(row[2],row[3])<min_face_pixels:
                    continue
                if clamp_boxes_before_alignment:
                    x,y,bw,bh=row[:4]
                    left=max(0,min(original_w,int(np.floor(x))))
                    top=max(0,min(original_h,int(np.floor(y))))
                    right=max(0,min(original_w,int(np.ceil(x+bw))))
                    bottom=max(0,min(original_h,int(np.ceil(y+bh))))
                    if right <= left or bottom <= top:
                        continue
                    row[:4]=(left,top,right-left,bottom-top)
                try:
                    aligned=self.recognizer.alignCrop(image,row).copy()
                except cv2.error as exc:
                    raise PlatformError("face_alignment_failed",422) from exc
                if aligned.shape != (112,112,3) or aligned.dtype != np.uint8:
                    raise PlatformError("model_output_invalid",503)
                vec=self.recognizer.feature(aligned).reshape(-1).astype(np.float32)
                norm=float(np.linalg.norm(vec))
                if vec.shape!=(DIMENSIONS,) or norm<1e-8 or not np.isfinite(vec).all():
                    raise PlatformError("model_output_invalid",503)
                points=row[4:14].reshape(5,2)
                eye_mid=(points[0]+points[1])/2
                eye_distance=max(1.,float(np.linalg.norm(points[0]-points[1])))
                # Proxy is camera-coordinate nose offset, not calibrated anatomical yaw.
                yaw=float((points[2][0]-eye_mid[0])/eye_distance)
                output.append(ImageFace(row[:4].tolist(),points.tolist(),float(row[14]),
                    (vec/norm).tolist(),aligned,quality(image,row),yaw))
            return output

    def photo(self, data: bytes | EvidenceFile, *, max_pixels: int | None = None) -> list[Face]:
        decoded = decode_photo(data, self.max_photo_pixels if max_pixels is None else max_pixels)
        faces = self.analyze(decoded.pixels, True)
        h, w = decoded.pixels.shape[:2]
        sx, sy = decoded.original_width / w, decoded.original_height / h
        for face in faces:
            x, y, bw, bh = face.bbox
            face.bbox = [x*sx, y*sy, bw*sx, bh*sy]
            face.landmarks = [[x*sx, y*sy] for x, y in face.landmarks]
        return faces
