"""One private still-only lane reusing canonical deadlines and reaping.

No HTTP listener, account settings, database, broker, PAD or video graph exists
in this distribution. OS resource and network restrictions belong to its host.
"""
from __future__ import annotations

import base64
from dataclasses import asdict
import math
import os
from pathlib import Path
import re
import sys

import numpy as np

from .artifact import ENGINE_ARTIFACT_SHA256
from .engine import CONTRACT_VERSION, MODEL_SHA256, StillFace, StillImagePolicy, StillImageResult, _canonical_sha256
from ._core.errors import PlatformError
from ._core.isolation import WorkerChannel, _embedding, _numbers, child_environment
from ._core.media import local_evidence
from ._core.spool import EvidenceStore

MAX_REPLY = 8 * 1024 * 1024
_HASH = re.compile(r"[a-f0-9]{64}\Z")


def validate_identity(value: dict) -> None:
    expected = {"contract_version", "model_version", "engine_artifact_sha256", "artifact_fingerprint",
                "policy_sha256", "model_sha256", "runtime_versions", "processing_fingerprint"}
    if (not isinstance(value, dict) or set(value) != expected or value["contract_version"] != CONTRACT_VERSION
            or value["model_version"] != "opencv-yunet-sface-2021dec-v1"
            or value["engine_artifact_sha256"] != ENGINE_ARTIFACT_SHA256
            or value["model_sha256"] != MODEL_SHA256
            or any(not isinstance(value[k], str) or not _HASH.fullmatch(value[k])
                   for k in ("artifact_fingerprint", "policy_sha256", "processing_fingerprint"))
            or not isinstance(value["runtime_versions"], dict)
            or set(value["runtime_versions"]) != {"opencv", "numpy", "pillow"}
            or any(not isinstance(v, str) or not 1 <= len(v) <= 100 for v in value["runtime_versions"].values())
            or value["processing_fingerprint"] != _canonical_sha256({k:v for k,v in value.items() if k != "processing_fingerprint"})):
        raise PlatformError("inference_protocol_error", 503)


class StillChannel(WorkerChannel):
    max_reply = MAX_REPLY
    allowed_operations = ("analyze", "ping")

    def _validate_metadata(self, incoming: dict) -> None:
        validate_identity(incoming)
        if incoming["policy_sha256"] != _canonical_sha256(self.config["policy"]):
            raise PlatformError("inference_protocol_error", 503)

    def _child_environment(self) -> dict[str, str]:
        env = child_environment(self.config["threads"])
        # Exact installed wheel's namespace, including target-directory installs.
        env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1])
        return env


class StillImageRuntime:
    def __init__(self, model_dir: str | Path, *, policy: StillImagePolicy, threads: int=1,
                 deadline_seconds: float=40, boot_deadline_seconds: float=60,
                 evidence_root: Path | None=None, max_workers: int=1):
        if (not isinstance(policy, StillImagePolicy) or type(threads) is not int or not 1 <= threads <= 4
                or type(max_workers) is not int or max_workers != 1):
            raise ValueError("invalid_still_configuration")
        for value in (deadline_seconds, boot_deadline_seconds):
            if type(value) not in (int, float) or not math.isfinite(value) or not 0 < value <= 120:
                raise ValueError("invalid_inference_deadline")
        self.policy = policy
        self._store = EvidenceStore(evidence_root)
        self._channel = StillChannel({"model_dir": str(Path(model_dir).resolve()), "policy": asdict(policy),
                                      "threads": threads, "evidence_dir": str(self._store.directory),
                                      "parent_pid": os.getpid()},
                                     timeout=deadline_seconds, boot_timeout=boot_deadline_seconds,
                                     lease_fd=self._store.lease_fd,
                                     argv=[sys.executable, "-m", "openface_still.worker"])
        try:
            self.identity = self._channel.initialize()
        except BaseException:
            self.close()
            raise

    def analyze(self, image_bytes: bytes, *, content_type: str) -> StillImageResult:
        if content_type not in ("image/jpeg", "image/png", "image/webp"):
            raise PlatformError("unsupported_image_type", 422)
        with local_evidence(image_bytes, limit=self.policy.max_encoded_bytes,
                            suffix=".image", directory=str(self._store.directory)) as evidence:
            value = self._channel.call("analyze", {"content_type": content_type,
                "evidence": {"path": str(evidence.path.resolve()), "size": evidence.size, "sha256": evidence.sha256}})
        if (not isinstance(value, dict) or set(value) != {"width", "height", "faces", "identity"}
                or value["identity"] != self.identity
                or type(value["width"]) is not int or type(value["height"]) is not int
                or not 0 < value["width"]*value["height"] <= self.policy.max_decoded_pixels
                or min(value["width"], value["height"]) < self.policy.min_image_edge
                or not isinstance(value["faces"], list) or len(value["faces"]) > self.policy.max_faces):
            self._invalid()
        faces = []
        try:
            for face in value["faces"]:
                if not isinstance(face, dict) or set(face) != {"bbox", "landmarks", "confidence", "embedding", "aligned_bgr", "quality", "yaw_proxy"}:
                    self._invalid()
                bbox = face["bbox"]
                if (not isinstance(bbox, dict) or set(bbox) != {"x", "y", "width", "height"}
                        or any(type(v) is not int for v in bbox.values()) or min(bbox["x"], bbox["y"]) < 0
                        or min(bbox["width"], bbox["height"]) <= 0
                        or bbox["x"]+bbox["width"] > value["width"] or bbox["y"]+bbox["height"] > value["height"]):
                    self._invalid()
                points = face["landmarks"]
                if not isinstance(points, dict) or set(points) != {"right_eye", "left_eye", "nose", "mouth_right", "mouth_left"}:
                    self._invalid()
                for point in points.values():
                    _numbers(point, 2)
                _numbers([face["confidence"], face["quality"]], 2, 0, 1)
                _numbers([face["yaw_proxy"]], 1)
                embedding = _embedding(face["embedding"])
                if not isinstance(face["aligned_bgr"], str) or len(face["aligned_bgr"]) != 112*112*3*4//3:
                    self._invalid()
                raw = base64.b64decode(face["aligned_bgr"], validate=True)
                if len(raw) != 112*112*3:
                    self._invalid()
                pixels = np.frombuffer(raw, dtype=np.uint8).reshape(112,112,3).copy()
                faces.append(StillFace(bbox, points, face["confidence"], embedding, pixels, face["quality"], face["yaw_proxy"]))
        except (ValueError, TypeError, KeyError) as exc:
            self._channel.close()
            raise PlatformError("inference_output_invalid", 503) from exc
        except PlatformError:
            self._channel.close()
            raise
        return StillImageResult(value["width"], value["height"], tuple(faces), dict(self.identity))

    def _invalid(self):
        self._channel.close()
        raise PlatformError("inference_output_invalid", 503)

    def probe(self) -> bool:
        state = self._channel.probe()
        if state != "ready":
            raise PlatformError(state, 503)
        return True

    def status(self) -> dict:
        return self._channel.status()

    def close(self) -> None:
        # Never release the evidence lease before terminating/reaping the child.
        self._channel.close()
        self._store.close()

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()
