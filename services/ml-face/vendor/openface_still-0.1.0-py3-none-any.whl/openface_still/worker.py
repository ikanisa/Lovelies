"""Private account-free still worker protocol; no socket or video/PAD import."""
from __future__ import annotations

import base64
from dataclasses import asdict
import json
import os
from pathlib import Path
import signal
import sys

from .engine import StillImageEngine, StillImagePolicy
from .runtime import MAX_REPLY
from ._core.errors import PlatformError
from ._core.isolation import MAX_REQUEST, _json
from ._core.media import EvidenceFile


def initialize(config):
    if (not isinstance(config, dict) or set(config) != {"model_dir", "policy", "threads", "evidence_dir", "parent_pid"}
            or type(config["parent_pid"]) is not int or not 1 <= config["parent_pid"] <= 2**31
            or not isinstance(config["model_dir"], str) or not isinstance(config["evidence_dir"], str)):
        raise ValueError("invalid_still_configuration")
    import resource
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    if sys.platform.startswith("linux"):
        import ctypes
        if ctypes.CDLL(None, use_errno=True).prctl(1, int(signal.SIGKILL), 0, 0, 0) != 0:
            raise OSError("parent_death_signal_failed")
    if os.getppid() != config["parent_pid"]:
        raise RuntimeError("parent_exited")
    policy = StillImagePolicy(**config["policy"])
    engine = StillImageEngine(config["model_dir"], policy=policy, threads=config["threads"])
    return engine


def dispatch(message, engine, config):
    if message.get("op") == "ping" and set(message) == {"id", "op"}:
        return {"ready": True}
    if message.get("op") != "analyze" or set(message) != {"id", "op", "evidence", "content_type"}:
        raise PlatformError("inference_request_invalid", 503)
    reference = message["evidence"]
    if not isinstance(reference, dict) or set(reference) != {"path", "size", "sha256"}:
        raise PlatformError("inference_request_invalid", 503)
    with EvidenceFile.borrow(reference, root=Path(config["evidence_dir"]), limit=engine.policy.max_encoded_bytes) as source:
        result = engine.analyze(source, content_type=message["content_type"])
    faces = []
    for face in result.faces:
        value = {key: val for key, val in asdict(face).items() if key != "aligned_pixels"}
        value["aligned_bgr"] = base64.b64encode(face.aligned_pixels.tobytes()).decode("ascii")
        faces.append(value)
    return {"width": result.width, "height": result.height, "identity": result.identity, "faces": faces}


def main() -> int:
    config = engine = None
    while True:
        line = sys.stdin.buffer.readline(MAX_REQUEST+1)
        if not line:
            return 0
        request_id = None
        stop = False
        try:
            if len(line) > MAX_REQUEST or not line.endswith(b"\n"):
                return 2
            message = _json(line)
            request_id = message.get("id")
            if not isinstance(request_id, str) or len(request_id) != 32:
                return 2
            if config is None:
                if set(message) != {"id", "op", "config"} or message["op"] != "initialize":
                    return 2
                config = message["config"]
                engine = initialize(config)
                result = engine.identity
            else:
                result = dispatch(message, engine, config)
            response = {"id": request_id, "ok": True, "result": result}
        except PlatformError as exc:
            response = {"id": request_id, "ok": False, "error": exc.code, "status": exc.status}
            stop = exc.status >= 500
        except Exception:
            response = {"id": request_id, "ok": False, "error": "inference_worker_failed", "status": 503}
            stop = True
        encoded = (json.dumps(response, allow_nan=False, separators=(",", ":"))+"\n").encode()
        if len(encoded) > MAX_REPLY:
            return 2
        try:
            sys.stdout.buffer.write(encoded)
            sys.stdout.buffer.flush()
        except BrokenPipeError:
            return 0
        if stop:
            return 1


if __name__ == "__main__":
    raise SystemExit(main())
